# 证据包索引

本目录用于集中存放软件杯 A3 答辩与配套文档所需的运行证据、页面截图和接口验证结果，方便评委或指导老师按条核验。

## 1. 目录结构

1. `api/`：知识库上传、检索、问答、状态查询的真实接口返回结果
2. `screenshots/`：关键页面截图归档
3. `runtime_checks.md`：运行环境与当前核验结论
4. `knowledge_base_validation.md`：课程知识库样例包验证记录

## 2. 当前重点证据

1. 首页与登录页截图：用于说明系统可访问、演示入口清晰
2. 学习画像、智能问答、能力测试、学习报告、学习计划、赛题对照页截图：用于说明功能闭环完整
3. 课程知识库样例包真实验证结果：用于说明系统不是“只写了功能介绍”，而是确实完成了上传、索引、检索和 RAG 问答
4. 根目录答辩 PPT：`学智画像_A3答辩初稿_深墨蓝科技风.pptx`

## 3. 推荐答辩引用顺序

1. 先展示 `screenshots/competition_readiness.png`，总览赛题完成度
2. 再展示 `screenshots/intelligent_assistant.png` 与 `screenshots/assessment.png`，解释多智能体和测评闭环
3. 若评委追问知识库与反幻觉，直接引用 `knowledge_base_validation.md` 与 `api/` 下 JSON 结果
4. 若需要工程化佐证，再补 `runtime_checks.md` 中的访问与账号信息

## 4. 当前仍可继续补充的证据

1. 资源生成成功案例截图
2. `start.bat` 启动截图
3. Docker 启动与访问截图
4. 更细的内容安全过滤测试记录
