# 学智画像 - 安全部署执行脚本
# 此脚本包含服务器密码，注意保密

param(
    [string]$ServerIP = "123.56.247.117",
    [string]$User = "root",
    [string]$Password = "Huyi601@",
    [string]$RemoteDir = "/opt/xuezhi-portrait"
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

$TIMESTAMP = Get-Date -Format "yyyyMMdd_HHmmss"
$PACKAGE_NAME = "deploy_package_${TIMESTAMP}.tar.gz"
$REMOTE_SCRIPT = "safe_deploy_remote.sh"

function Write-Info { Write-Host "[INFO] $args" -ForegroundColor Cyan }
function Write-Success { Write-Host "[OK]   $args" -ForegroundColor Green }
function Write-Warn { Write-Host "[WARN] $args" -ForegroundColor Yellow }
function Write-Error { Write-Host "[ERROR] $args" -ForegroundColor Red }
function Write-Step { Write-Host "`n============================================" -ForegroundColor Blue; Write-Host ">>> $args" -ForegroundColor Blue; Write-Host "============================================" -ForegroundColor Blue }

# 使用 sshpass 或 plink 进行密码认证
function Invoke-SSHWithPassword {
    param([string]$Command)
    
    # 使用 Plink (PuTTY) 如果可用，否则尝试 sshpass (需安装)
    $plinkPath = "plink.exe"
    
    # 先尝试查找 plink
    try {
        $plinkFull = Get-Command plink -ErrorAction SilentlyContinue
        if ($plinkFull) { $plinkPath = $plinkFull.Source }
    } catch {}
    
    if (Test-Path $plinkPath) {
        # 使用 Plink
        $output = echo "y" | & $plinkPath -ssh -batch -l $User -pw $Password $ServerIP $Command 2>&1
        return $output
    } else {
        # 使用 sshpass (Linux) 或提示手动执行
        Write-Warn "未找到 Plink，尝试使用标准 SSH (可能需手动输入密码)..."
        # 创建 expect 脚本或直接使用交互式
        ssh -o StrictHostKeyChecking=no "${User}@${ServerIP}" $Command
    }
}

function Invoke-SCPWithPassword {
    param([string]$Source, [string]$Dest)
    
    # 尝试使用 pscp (PuTTY)
    $pscpPath = "pscp.exe"
    try {
        $pscpFull = Get-Command pscp -ErrorAction SilentlyContinue
        if ($pscpFull) { $pscpPath = $pscpFull.Source }
    } catch {}
    
    if (Test-Path $pscpPath) {
        echo "y" | & $pscpPath -batch -l $User -pw $Password "$Source" "${ServerIP}:${Dest}"
    } else {
        Write-Warn "未找到 PSCP，尝试使用 scp..."
        scp -o StrictHostKeyChecking=no "$Source" "${User}@${ServerIP}:${Dest}"
    }
}

Write-Host @"
╔══════════════════════════════════════════════════════╗
║       学智画像 - 零风险安全部署工具 v2.0              ║
║       目标: ${ServerIP}                                ║
╚══════════════════════════════════════════════════════╝
"@

# 检查必要命令
Write-Step "Phase 0: 检查本地环境"

$hasSSH = $false
$hasSCP = $false

try { ssh -V 2>&1 | Out-Null; $hasSSH = $true } catch {}
try { scp -V 2>&1 | Out-Null; $hasSCP = $true } catch {}

if ($hasSSH -and $hasSCP) {
    Write-Success "SSH 和 SCP 已就绪"
} else {
    Write-Error "缺少 SSH/SCP 命令。请确保 OpenSSH 已安装。"
    exit 1
}

# Phase 1: 连接验证
Write-Step "Phase 1: 连接验证"

try {
    Write-Info "测试 SSH 连接 (首次连接需手动确认)..."
    # 使用 -tt 强制伪终端以处理密码输入
    $testCmd = @"
echo $Password | ssh -tt -o StrictHostKeyChecking=no -o ConnectTimeout=10 ${User}@${ServerIP} "hostname && echo 'SSH_OK'"
"@
    $result = Invoke-Expression $testCmd 2>&1
    if ($result -match "SSH_OK") {
        Write-Success "SSH 连接成功"
    } else {
        Write-Warn "SSH 测试返回: $result"
    }
} catch {
    Write-Warn "SSH 自动测试失败: $_"
    Write-Info "将在后续步骤中尝试手动输入密码"
}

# Phase 2: 打包上传
Write-Step "Phase 2: 打包并上传"

Write-Info "创建部署包..."
$excludeList = @("__pycache__", "*.pyc", "*.pyo", ".git", ".vscode", ".idea", "node_modules", "instance", "logs", "*.db", "*.sqlite", "*.sqlite3", "_competition_package", "*.egg-info", "xuezhi-portrait-source.zip", "deploy_package_*.tar.gz")

$tarExclude = ($excludeList | ForEach-Object { "--exclude='$_'" }) -join " "
$tarCmd = "tar $tarExclude -czf '$PACKAGE_NAME' -C '$scriptDir' ."

Write-Host "  [TAR] $tarCmd" -ForegroundColor DarkGray
Invoke-Expression $tarCmd 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Error "打包失败"
    exit 1
}

$pkgSize = [math]::Round((Get-Item $PACKAGE_NAME).Length / 1MB, 2)
Write-Success "部署包已创建: $PACKAGE_NAME ($pkgSize MB)"

Write-Info "上传部署包到服务器 /tmp/..."
Write-Warn "需要手动输入密码: $Password"

$uploadCmd = @"
echo $Password | scp -o StrictHostKeyChecking=no -o ConnectTimeout=30 '$PACKAGE_NAME' '${User}@${ServerIP}:/tmp/$PACKAGE_NAME'
"@
try {
    Invoke-Expression $uploadCmd 2>&1
    Write-Success "部署包上传完成"
} catch {
    Write-Error "上传失败: $_"
    exit 1
}

Write-Info "上传远程部署脚本..."
$uploadScript = @"
echo $Password | scp -o StrictHostKeyChecking=no '$REMOTE_SCRIPT' '${User}@${ServerIP}:/tmp/$REMOTE_SCRIPT'
"@
Invoke-Expression $uploadScript 2>&1

# 清理本地临时包
Remove-Item "$scriptDir\$PACKAGE_NAME" -Force

# Phase 3: 执行远程部署
Write-Step "Phase 3: 服务器端执行安全部署"
Write-Warn "需要在 SSH 会话中手动输入密码"
Write-Host ""

$deployCmd = @"
echo $Password | ssh -tt -o StrictHostKeyChecking=no ${User}@${ServerIP} "bash /tmp/$REMOTE_SCRIPT deploy '$RemoteDir' '/tmp/$PACKAGE_NAME' '$TIMESTAMP'"
"@

Write-Host "即将执行部署命令..." -ForegroundColor Yellow
Write-Host "如果提示密码，请输入: $Password" -ForegroundColor Magenta
Write-Host ""

# 创建并执行一个批处理文件来处理交互式SSH
$batchPath = "$env:TEMP\deploy_ssh_$TIMESTAMP.bat"
@"
@echo off
echo 正在连接服务器执行部署...
echo 如果提示密码，请输入: $Password
echo.
ssh -o StrictHostKeyChecking=no ${User}@${ServerIP} "bash /tmp/$REMOTE_SCRIPT deploy '$RemoteDir' '/tmp/$PACKAGE_NAME' '$TIMESTAMP'"
pause
"@ | Out-File -FilePath $batchPath -Encoding ASCII

Write-Info "已生成批处理文件: $batchPath"
Write-Info "请运行以下命令完成部署:"
Write-Host ""
Write-Host "  cmd /c `"$batchPath`"" -ForegroundColor Green
Write-Host ""

# 也提供直接执行的选项
$runDirect = Read-Host "是否立即启动部署窗口? (Y/n)"
if ($runDirect -ne "n" -and $runDirect -ne "N") {
    Start-Process cmd -ArgumentList "/c `"$batchPath`"" -Wait
    
    # 部署后清理
    Write-Step "清理"
    Remove-Item $batchPath -Force -ErrorAction SilentlyContinue
    
    Write-Host @"

╔══════════════════════════════════════════════════════╗
║              部署脚本执行完成                         ║
╠══════════════════════════════════════════════════════╣
║  访问地址 : http://${ServerIP}                         ║
║  备份位置 : ${RemoteDir}_backup_${TIMESTAMP}           ║
╠══════════════════════════════════════════════════════╣
║  查看日志 :                                           ║
║  ssh ${User}@${ServerIP}                               ║
║  cd ${RemoteDir} && docker compose logs -f web         ║
╠══════════════════════════════════════════════════════╣
║  回滚命令 :                                           ║
║  bash ${RemoteDir}_backup_${TIMESTAMP}/rollback.sh    ║
╚══════════════════════════════════════════════════════╝

"@
}

Write-Info "如需手动执行，请 SSH 登录服务器后运行:"
Write-Host "  bash /tmp/$REMOTE_SCRIPT deploy '$RemoteDir' '/tmp/$PACKAGE_NAME' '$TIMESTAMP'" -ForegroundColor Cyan
